import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../utils/api";

export default function Dashboard() {
  const [user, setUser] = useState(JSON.parse(localStorage.getItem("user")));
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  const navigate = useNavigate();

  // Logout and clear JWT tokens
  const logout = () => {
    localStorage.removeItem("user");
    localStorage.removeItem("accessToken");
    localStorage.removeItem("refreshToken");
    navigate("/");
  };

  useEffect(() => {
    const fetchDashboard = async () => {
      setLoading(true);
      try {
        // Access token automatically sent via Axios interceptor
        const res = await api.get("/users/dashboard");
        setData(res.data);
      } catch (err) {
        // If JWT expired or invalid, interceptor will try refresh token
        // If refresh fails, we logout
        alert("Session expired or invalid. Please login again.");
        logout();
      }
      setLoading(false);
    };

    fetchDashboard();
  }, []);

  return (
    <div style={styles.wrapper}>
      <div style={styles.card}>
        <h2>Welcome, {user?.name || user?.email}</h2>

        {loading ? (
          <p>Loading your dashboard...</p>
        ) : (
          <div style={styles.info}>
            <p>{data?.message}</p>
            <p>User Role: {user?.role || "user"}</p>
          </div>
        )}

        <button style={styles.logout} onClick={logout}>
          Logout
        </button>
      </div>
    </div>
  );
}

const styles = {
  wrapper: {
    height: "100vh",
    width: "100%",
    background: "#f6f7f9",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontFamily: "Arial",
  },
  card: {
    width: 400,
    background: "#fff",
    padding: 30,
    borderRadius: 12,
    boxShadow: "0 4px 20px rgba(0,0,0,0.1)",
    textAlign: "center",
  },
  info: {
    margin: "20px 0",
    fontSize: 16,
    color: "#333",
  },
  logout: {
    padding: 12,
    width: "100%",
    background: "#ff3b30",
    color: "#fff",
    border: "none",
    borderRadius: 8,
    cursor: "pointer",
    fontSize: 16,
  },
};
