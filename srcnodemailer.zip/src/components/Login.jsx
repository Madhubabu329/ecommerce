import React, { useState } from "react";
import api from "../utils/api";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [timer, setTimer] = useState(0);
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();

  // Start OTP timer
  const startTimer = () => {
    setTimer(60);
    const interval = setInterval(() => {
      setTimer((t) => {
        if (t <= 1) clearInterval(interval);
        return t - 1;
      });
    }, 1000);
  };

  // Send OTP
  const sendOtp = async () => {
    if (!email) return alert("Please enter email");

    setLoading(true);
    try {
      const res = await api.post("/auth/send-otp", { email, name });
      alert(res.data.message);
      setStep(2);
      startTimer();
    } catch (err) {
      alert(err.response?.data?.message || "Error sending OTP");
    }
    setLoading(false);
  };

  // Verify OTP
  const verifyOtp = async () => {
    if (!otp) return alert("Enter OTP");

    setLoading(true);
    try {
      const res = await api.post("/auth/verify-otp", { email, code: otp, name });

      localStorage.setItem("accessToken", res.data.accessToken);
      localStorage.setItem("refreshToken", res.data.refreshToken);
      localStorage.setItem("user", JSON.stringify(res.data.user));

      navigate("/dashboard");
    } catch (err) {
      alert(err.response?.data?.message || "OTP verification failed");
    }
    setLoading(false);
  };

  return (
    <div style={styles.wrapper}>
      <div style={styles.card}>
        <h2 style={{ marginBottom: 20 }}>Login with OTP</h2>

        {/* Step 1 → Enter Email + Name */}
        {step === 1 && (
          <>
            <input
              placeholder="Your Name"
              style={styles.input}
              value={name}
              onChange={(e) => setName(e.target.value)}
            />

            <input
              placeholder="Email Address"
              style={styles.input}
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />

            <button style={styles.button} onClick={sendOtp}>
              {loading ? "Sending OTP..." : "Send OTP"}
            </button>
          </>
        )}

        {/* Step 2 → Enter OTP */}
        {step === 2 && (
          <>
            <input
              placeholder="Enter OTP"
              style={styles.input}
              value={otp}
              onChange={(e) => setOtp(e.target.value)}
            />

            <button style={styles.button} onClick={verifyOtp}>
              {loading ? "Verifying..." : "Verify OTP"}
            </button>

            {/* Resend OTP Button */}
            <button
              disabled={timer > 0}
              onClick={sendOtp}
              style={{
                ...styles.resend,
                opacity: timer > 0 ? 0.4 : 1,
                cursor: timer > 0 ? "not-allowed" : "pointer",
              }}
            >
              {timer > 0 ? `Resend OTP (${timer})` : "Resend OTP"}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

const styles = {
  wrapper: {
    height: "100vh",
    width: "100%",
    background: "#f6f7f9",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    fontFamily: "Arial",
  },
  card: {
    width: 350,
    background: "#fff",
    padding: 30,
    borderRadius: 12,
    boxShadow: "0 4px 15px rgba(0,0,0,0.1)",
    textAlign: "center",
  },
  input: {
    width: "100%",
    padding: 12,
    fontSize: 16,
    marginBottom: 12,
    borderRadius: 8,
    border: "1px solid #ddd",
    outline: "none",
  },
  button: {
    width: "100%",
    padding: 12,
    fontSize: 16,
    background: "#ff6a00",
    color: "#fff",
    border: "none",
    borderRadius: 8,
    cursor: "pointer",
    marginBottom: 10,
  },
  resend: {
    width: "100%",
    padding: 12,
    fontSize: 16,
    background: "#333",
    color: "#fff",
    border: "none",
    borderRadius: 8,
  },
};
