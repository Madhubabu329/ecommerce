const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const bodyParser = require("body-parser");
const dotenv = require("dotenv");
const nodemailer = require("nodemailer");
const jwt = require("jsonwebtoken");

const User = require("./models/User");
const Otp = require("./models/Otp");
const auth = require("./middleware/auth");

dotenv.config();
const app = express();
app.use(cors());
app.use(bodyParser.json());

mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

// Setup Nodemailer
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Generate OTP
function generateOtp() {
  return Math.floor(100000 + Math.random() * 900000).toString();
}

// Send OTP
app.post("/api/send-otp", async (req, res) => {
  const { email, name } = req.body;
  const code = generateOtp();
  const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

  await Otp.findOneAndUpdate(
    { email },
    { code, expiresAt },
    { upsert: true, new: true }
  );

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: email,
    subject: "Your OTP Code",
    text: `Hello ${name || ""}, your OTP code is: ${code}. It expires in 5 minutes.`
  };

  transporter.sendMail(mailOptions, (err) => {
    if (err) return res.status(500).json({ success: false, message: err.message });
    res.json({ success: true, message: "OTP sent successfully" });
  });
});

// Verify OTP and generate JWT
app.post("/api/verify-otp", async (req, res) => {
  const { email, code, name } = req.body;
  const otpRecord = await Otp.findOne({ email });

  if (!otpRecord) return res.status(400).json({ success: false, message: "OTP not found" });
  if (otpRecord.expiresAt < new Date()) return res.status(400).json({ success: false, message: "OTP expired" });
  if (otpRecord.code !== code) return res.status(400).json({ success: false, message: "Invalid OTP" });

  // Save user
  let user = await User.findOne({ email });
  if (!user) {
    user = new User({ email, name });
    await user.save();
  }

  await Otp.deleteOne({ email });

  const payload = { id: user._id, email: user.email };
  const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: "1h" });

  res.json({ success: true, message: "Login successful", user, token });
});

// Protected route example
app.get("/api/dashboard", auth, (req, res) => {
  res.json({ message: "Welcome to dashboard", user: req.user });
});

app.listen(process.env.PORT || 5000, () => console.log("Server running on port", process.env.PORT));
