app.post("/api/verify-otp", async (req, res) => {
  const { email, code, name } = req.body;
  const otpRecord = await Otp.findOne({ email });

  if (!otpRecord) return res.status(400).json({ success: false, message: "OTP not found" });
  if (otpRecord.expiresAt < new Date()) return res.status(400).json({ success: false, message: "OTP expired" });
  if (otpRecord.code !== code) return res.status(400).json({ success: false, message: "Invalid OTP" });

  // Save user
  let user = await User.findOne({ email });
  if (!user) {
    user = new User({ email, name });
    await user.save();
  }

  // Delete OTP
  await Otp.deleteOne({ email });

  // Generate JWT
  const payload = { id: user._id, email: user.email };
  const token = jwt.sign(payload, "yourSecretKey", { expiresIn: "1h" });

  res.json({ success: true, message: "Login successful", user, token });
});
