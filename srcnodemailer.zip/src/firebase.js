// import { initializeApp } from "firebase/app";
// import { getAuth } from "firebase/auth";

// const firebaseConfig = {
//   apiKey: "YOUR_API_KEY",
//   authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
//   projectId: "YOUR_PROJECT_ID",
//   storageBucket: "YOUR_PROJECT_ID.appspot.com",
//   messagingSenderId: "YOUR_SENDER_ID",
//   appId: "YOUR_APP_ID"
// };

// const app = initializeApp(firebaseConfig);
// export const auth = getAuth(app);

import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

// Your Firebase config
const firebaseConfig = {
  apiKey: "AIzaSyDBcXo0MrqxhqEFiYQC0YclK3_bxmAbZO4",
  authDomain: "myclientmilk.firebaseapp.com",
  projectId: "myclientmilk",
  storageBucket: "myclientmilk.firebasestorage.app",
  messagingSenderId: "461169109106",
  appId: "1:461169109106:web:cede8de173490f87a7faeb",
  measurementId: "G-QS37788MTX"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export the auth instance
export const auth = getAuth(app);
