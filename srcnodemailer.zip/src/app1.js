import React, { useEffect, useState } from "react";
import axios from "axios";
import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from "react-router-dom";

function Login({ setUser }) {
  const [step, setStep] = useState(1);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [otp, setOtp] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const sendOtp = async () => {
    try {
      const res = await axios.post("http://localhost:5000/api/send-otp", { email, name });
      setMessage(res.data.message);
      setStep(2);
    } catch (err) {
      setMessage(err.response?.data?.message || err.message);
    }
  };

  const verifyOtp = async () => {
    try {
      const res = await axios.post("http://localhost:5000/api/verify-otp", { email, code: otp, name });
      setMessage(res.data.message);

      localStorage.setItem("token", res.data.token);
      localStorage.setItem("user", JSON.stringify(res.data.user));
      setUser(res.data.user);

      navigate("/dashboard");
    } catch (err) {
      setMessage(err.response?.data?.message || err.message);
    }
  };

  return (
    <div style={styles.container}>
      <h2>Login with Email OTP</h2>
      {step === 1 && (
        <>
          <input placeholder="Name" value={name} onChange={e => setName(e.target.value)} style={styles.input} />
          <input placeholder="Email" value={email} onChange={e => setEmail(e.target.value)} style={styles.input} />
          <button onClick={sendOtp} style={styles.button}>Send OTP</button>
        </>
      )}
      {step === 2 && (
        <>
          <input placeholder="Enter OTP" value={otp} onChange={e => setOtp(e.target.value)} style={styles.input} />
          <button onClick={verifyOtp} style={styles.button}>Verify OTP</button>
        </>
      )}
      <p>{message}</p>
    </div>
  );
}

function Dashboard({ user, setUser }) {
  const [data, setData] = useState(null);
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setUser(null);
    navigate("/");
  };

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) return logout();

    axios.get("http://localhost:5000/api/dashboard", {
      headers: { Authorization: `Bearer ${token}` }
    })
      .then(res => {
        setData(res.data);
      })
      .catch(err => {
        alert("Session expired. Please login again.");
        logout();
      });
  }, []);

  if (!user) return <Navigate to="/" />;

  return (
    <div style={styles.container}>
      <h2>Dashboard</h2>
      <p>Welcome, {user.name || user.email}!</p>
      {data && <p>{data.message}</p>}
      <button onClick={logout} style={styles.button}>Logout</button>
    </div>
  );
}

export default function App1() {
  const [user, setUser] = useState(
    JSON.parse(localStorage.getItem("user")) || null
  );

  // Auto-login and token validation
  useEffect(() => {
    const token = localStorage.getItem("token");
    const savedUser = JSON.parse(localStorage.getItem("user"));

    if (token && savedUser) {
      axios.get("http://localhost:5000/api/dashboard", {
        headers: { Authorization: `Bearer ${token}` }
      }).then(res => {
        setUser(savedUser);
      }).catch(err => {
        localStorage.removeItem("token");
        localStorage.removeItem("user");
        setUser(null);
      });
    }
  }, []);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login setUser={setUser} />} />
        <Route path="/dashboard" element={<Dashboard user={user} setUser={setUser} />} />
      </Routes>
    </Router>
  );
}

const styles = {
  container: { width: 300, margin: "100px auto", textAlign: "center", fontFamily: "Arial" },
  input: { width: "100%", padding: 10, margin: "10px 0", borderRadius: 5, border: "1px solid #ccc" },
  button: { width: "100%", padding: 10, margin: "10px 0", background: "#0284C7", color: "#fff", border: "none", borderRadius: 5, cursor: "pointer" },
};
