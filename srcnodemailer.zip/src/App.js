import logo from './logo.svg';
import './App.css';
import App1 from './app1';
import App12 from './components/app12';

function App() {
  return (
    <div className="App">
     <App12/>
    </div>
  );
}

export default App;
